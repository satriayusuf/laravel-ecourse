#include<iostream>
using namespace std;
main()
{
	char kodeBuku,beli,belanjaKmbl,buku[160];
	float totalByr,jumlahBeli,totalBeli,potongan,harga,hargaBuku;
	kembali:
		cout<<endl;
		cout<<"====================================================" ;cout<<endl;
		cout<<endl;
		cout<<"Masukan Kode Buku [1-5]:";cin>>kodeBuku;
		cout<<"Jumlah Pembelian :";cin>>jumlahBeli;cout<<endl;
		cout<<"====================================================" ;cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"\t Toko RPL Jaya";cout<<endl;
		cout<<"\t JL.Raya Cianjur-Bandung KM.09 Sukaluyu Cianjur";cout<<endl;
		cout<<endl;
		cout<<"====================================================" ;cout<<endl;
		cout<<endl;
		
		cout<<"Nama Buku    :"<<buku;
		switch(kodeBuku)
		{
			case('1'):
		{
			cout<<"Pengenalan Dasar C++"<<buku;
			hargaBuku= 40000;
			harga= 40000*jumlahBeli;
		}
		break;
		case('2'):
		{
			cout<<"Pemrograman C++"<<buku;
			hargaBuku=35000;
			harga=35000*jumlahBeli;
		}
		break;
		case('3'):
		{
			cout<<"Tips Membuat Blog"<<buku;
			hargaBuku=80000;
			harga=80000*jumlahBeli;
		}
		break;
		case('4'):
		{
			cout<<"Tips Mendesain Website"<<buku;
			hargaBuku=70000;
			harga=70000*jumlahBeli;
		}
		break;
		case('5'):
		{
			cout<<"Tips Membuat Pemrograman Java"<<buku;
			hargaBuku=90000;
			harga=90000*jumlahBeli;
		}
		break;
		}
		
		
		
		cout<<"Jumlah Buku :"<<jumlahBeli<<endl;
		cout<<"Harga Buku  :Rp."<<hargaBuku<<endl;
		if(jumlahBeli>3)
		{
			potongan = 0.05*harga;
		}
		else
		{
			potongan=0;
		}
		
		cout<<"Total harga buku : Rp."<<harga<<endl;
		cout<<"Potongan Harga   : Rp."<<potongan<<endl;
		
		
		
		totalByr= harga-potongan;
		cout<<"===================================================="<<endl;
		cout<<"Total Bayar   : Rp."<<totalByr<<endl;
		cout<<"===================================================="<<endl;
		cout<<endl;
		cout<<"Belanja Kembali? [Y/T] :";cin>>belanjaKmbl;
		if(belanjaKmbl=='Y' || belanjaKmbl=='y')
		{goto kembali;}
		if(belanjaKmbl=='T' || belanjaKmbl=='t')
		{goto selesai;}
		selesai:
			cout<<endl;
}
