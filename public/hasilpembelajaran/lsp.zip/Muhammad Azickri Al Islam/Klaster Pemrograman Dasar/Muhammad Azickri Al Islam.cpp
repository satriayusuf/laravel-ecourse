#include<iostream>
using namespace std;
main() {
	
	cout << "================================================================"; cout << endl;
	cout << endl;
	cout << "\t Toko Buku SMK Nurul Islam"; cout << endl;
	cout << "\t Jl. Raya Cianjur Bandung KM 09 Sukaluyu Cianjur"; cout << endl;
	cout << endl;
	cout << "================================================================"; cout << endl;
	cout << endl;
		
	// char , float, adalah variabel	
	char kodeBuku, beli, belanjaKmbl, buku[160];
	float totalByr, jumlahBli, totalBeli, potongan, harga, hargaBuku;
	kembali:

		cout << "\t Kode buku terdiri dari kode 1 sampai dengan 5" << endl;
		cout << "\t Masukan Kode Buku 	: "; cin >> kodeBuku;
		cout << "\t Jumlah Pembelian 	: "; cin >> jumlahBli; cout << endl;
		cout << "================================================================"; cout << endl;
		cout << endl;
		// cout , cin , adalah funcgsi input dan output
		
		cout << "\t Nama Buku 		 :" << buku;
		switch(kodeBuku) 
		{
			case('1'): 
			{
				cout << "Pengenalan Dasar C++" << buku;
				hargaBuku = 40000;
				harga = hargaBuku * jumlahBli;
				
				// hargaBuku * jumlahBli menggunakan operator kali (x)
			}
			break;
			
			case('2'): 
			{
				cout << "Pemrograman C++" << buku;
				hargaBuku = 35000;
				harga = hargaBuku * jumlahBli;
			}
			
			break;
		
			
			case('3'):
			{
				cout << "Tips Mmebuat Blog" << buku;
				hargaBuku = 80000;
				harga = hargaBuku * jumlahBli;
			}
			break;
			
			case('4'):
			{
				cout << "Tips Mendesain Web" << buku;
				hargaBuku = 70000;
				harga = hargaBuku * jumlahBli;
			}
			break;
			
			case('5'):
			{
				cout << "Tips Membuat Programan" << buku;
				hargaBuku = 90000;
				harga = hargaBuku * jumlahBli;
			}
			break;
		}
		
		cout << endl;
		cout << "\t Jumlah Buku 		 : " << jumlahBli << endl;
		cout << "\t Harga Buku 		 : Rp. " << hargaBuku << endl;
		
		if(jumlahBli > 3) {
			potongan = 0.05 * harga;
		} else {
			potongan = 0;
		}
		// percbangan kondisi if dan else
		
		cout << "\t Total Harga Buku 	 : Rp. " << harga << endl;
		cout << "\t Harga			 : Rp. " << potongan << endl;
		
		totalByr = harga - potongan;
		// harga - potongan, menggunakan operator pengurangan (-) 
		
		cout << "\t Total Bayar 	 	 : Rp. " << totalByr << endl;
		cout << endl;
		cout << "================================================================"; cout << endl;
		cout << endl;
		cout << "\t Belanja lagi? [Y/T]" << endl;
		cout << "\t "; cin >> belanjaKmbl;
		cout << endl;
		
		if(belanjaKmbl == 'Y' || belanjaKmbl == 'y') {
			goto kembali;
		} else if(belanjaKmbl == 'T' || belanjaKmbl == 't') {
			goto selesai;
		} else {
			cout << "\t Anda memasukan huruf yang salah, program akan ditutup!";
		}
		// percabangan kondisi if, else if, dan else
		
		selesai:
		cout << endl;
		
		
}
